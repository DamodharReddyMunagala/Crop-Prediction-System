import pandas as pd
import numpy as np

class DataAggregation():

    def __init__(self, state, district):
        self.state = state
        self.district = district
        self.season = pd.DataFrame()
        self.cropProd = pd.DataFrame()
        self.kharifCrop = pd.DataFrame()
        self.rabiCrop = pd.DataFrame()
        self.wholeYearCrop = pd.DataFrame()
        self.pastProduction = pd.DataFrame()


    def _cropProd(self, state):
        self.cropProd = pd.read_csv('District-wise, season-wise crop production statistics from 1997.csv')
        self.cropProd = self.cropProd.where(self.cropProd['State_Name'] == state)
        self.cropProd = self.cropProd.where(self.cropProd['District_Name'] == self.district.upper())
        self.cropProd['Season'] = self.cropProd['Season'].str.rstrip()
        self.cropProd = self.cropProd.dropna()
        self.cropProd['Crop_Year'] = pd.to_numeric(self.cropProd['Crop_Year'], downcast='integer')
        self.cropProd = self.cropProd.infer_objects()
        print(self.cropProd.head(5))

    
    def _initializingCropSeasons(self):
        self.kharifCrop = self.cropProd.where(self.cropProd['Season'] == 'Kharif')
        self.rabiCrop = self.cropProd.where(self.cropProd['Season'] == 'Rabi')
        self.wholeYearCrop = self.cropProd.where(self.cropProd['Season'] == 'Whole Year')


    def creatingColumns(self, colName):
        colName = pd.read_csv('./' + self.state + ' - ' + self.district + '/' + self.state + ' - ' + self.district + ' - ' + colName + ' 1901-2002.csv')
        colName['Kharif'] = (colName['Jul'] + colName['Aug'] + colName['Sep'] + colName['Oct']) / 4
        colName['Rabi'] = (colName['Oct'] + colName['Nov'] + colName['Dec'] + colName['Jan'] + colName['Feb'] + colName['Mar']) / 6
        colName['Whole Year'] = (colName['Jan'] + colName['Feb'] + colName['Mar'] + colName['Apr'] + colName['May'] + colName['Jun'] +
                            colName['Jul'] + colName['Aug'] + colName['Sep'] + colName['Oct'] + colName['Nov'] + colName['Dec']) / 12
        
        self.season['Crop_Year'] = colName['Year']
        self.season['Kharif'] = colName['Kharif']
        self.season['Rabi'] = colName['Rabi']
        self.season['Whole Year'] = colName['Whole Year']
    

    def addingColumns(self, colName):
        ### Adding column to the kharif season
        self.kharifCrop = self.kharifCrop.merge(self.season[['Crop_Year', 'Kharif']], how='inner', on='Crop_Year')
        self.kharifCrop = self.kharifCrop.rename(columns={'Kharif' : colName})

        ### Adding column to the rabi season
        self.rabiCrop = self.rabiCrop.merge(self.season[['Crop_Year', 'Rabi']], how='inner', on='Crop_Year')
        self.rabiCrop = self.rabiCrop.rename(columns={'Rabi' : colName})

        ### Adding column to the rabi season
        self.wholeYearCrop = self.wholeYearCrop.merge(self.season[['Crop_Year', 'Whole Year']], how='inner', on='Crop_Year')
        self.wholeYearCrop = self.wholeYearCrop.rename(columns={'Whole Year' : colName})

    def appendingAllSeasons(self):
        self.pastProduction = self.pastProduction.append([self.kharifCrop, self.rabiCrop, self.wholeYearCrop])
        self.pastProduction = self.pastProduction.sort_values(['Crop_Year', 'Season'])
        self.pastProduction['Crop_Year'] = pd.to_numeric(self.pastProduction['Crop_Year'], downcast='integer')
        self.pastProduction = self.pastProduction.infer_objects()
        self.pastProduction['Tonnes/Acres'] = self.pastProduction['Production'] / self.pastProduction['Area']

    
    def storingToCSV(self):
        self.pastProduction.to_csv(self.district + 'Production.csv')
    

    def columnNames(self):
        self._cropProd('Andhra Pradesh')
        self._initializingCropSeasons()
        colNames = ['Precipitation', 'MinTemp', 'MaxTemp', 'CloudCover', 'VapourPressure', 'WetDayFrequency',
                'DiurnalTemperatureRange', 'GroundFrostFrequency', 'ReferenceCropEvapotranspiration', 'PotentialEvapotranspiration']
        for colName in colNames:
            self.creatingColumns(colName)
            self.addingColumns(colName)
        
        self.appendingAllSeasons()
        self.storingToCSV()