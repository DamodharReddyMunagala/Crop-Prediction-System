from DataAggregation import DataAggregation

data = DataAggregation('AndhraPradesh', 'Chittoor')
data.columnNames()

data = DataAggregation('AndhraPradesh', 'Kadapa')
data.columnNames()

data = DataAggregation('AndhraPradesh', 'East Godavari')
data.columnNames()

data = DataAggregation('AndhraPradesh', 'Guntur')
data.columnNames()

data = DataAggregation('AndhraPradesh', 'SPSR Nellore')
data.columnNames()

data = DataAggregation('AndhraPradesh', 'Prakasam')
data.columnNames()

data = DataAggregation('AndhraPradesh', 'Visakhapatanam')
data.columnNames()

data = DataAggregation('AndhraPradesh', 'Vizianagaram')
data.columnNames()

data = DataAggregation('AndhraPradesh', 'West Godavari')
data.columnNames()

data = DataAggregation('Telangana', 'Karimnagar')
data.columnNames()

Karimnagar