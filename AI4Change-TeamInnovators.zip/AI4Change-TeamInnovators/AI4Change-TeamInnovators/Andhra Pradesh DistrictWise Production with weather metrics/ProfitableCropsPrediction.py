import sys
import numpy as np
import pandas as pd
from keras.models import model_from_json

class ProfitableCropsPrediction():
    def __init__(self, district, season, cropYear):
        self.district = district
        self.season = season
        self.cropYear = cropYear
        self.prodData = pd.DataFrame()
        self.crops = {'Rice' : [], 'Maize' : [], 'Jowar' : []}

    def _dataLoading(self, cropName):
        self.prodData = pd.read_csv(self.district + 'Production.csv')
        self.prodData = self.prodData.where(self.prodData['Crop'] == cropName)
        self.prodData = self.prodData.dropna()
        self.prodData = self.prodData.drop(columns=['State_Name', 'District_Name', 'Crop', 'Area', 'Production'])
        self.prodData = self.prodData.drop(self.prodData.columns[[0]], axis = 1)
        self.prodData = pd.get_dummies(self.prodData, columns=['Season'])
        self.prodData['Crop_Year'] = pd.to_numeric(self.prodData['Crop_Year'], downcast='integer')

    def _modelLoading(self, cropName):
        json_file = open('Prediction_Models/AP_' + cropName + '_Prediction.json', 'r')
        json_model = json_file.read()
        json_file.close()

        loaded_model = model_from_json(json_model)
        loaded_model.load_weights('Prediction_Models/AP_' + cropName + '_Prediction_ModelWeights.h5')
        loaded_model.compile(optimizer='adam', loss='mse')

        #Previous Year Production
        prevYearData = self.prodData.where(self.prodData['Crop_Year'] == (self.cropYear - 1))
        if self.season == 'Kharif':
            prevYearData = prevYearData.where(self.prodData['Season_Kharif'] == 1)
            prevYearData = prevYearData.dropna()
            self.crops[cropName].append(prevYearData['Tonnes/Acres'].values.item(0))
        else:
            prevYearData = prevYearData.where(self.prodData['Season_Kharif'] == 0)
            prevYearData = prevYearData.dropna()
            self.crops[cropName].append(prevYearData['Tonnes/Acres'].values.item(0))

        #Applying Conditions
        self.prodData = self.prodData.where(self.prodData['Crop_Year'] == self.cropYear)
        if self.season == 'Kharif':
            self.prodData = self.prodData.where(self.prodData['Season_Kharif'] == 1)
        else:
            self.prodData = self.prodData.where(self.prodData['Season_Kharif'] == 0)
        self.prodData = self.prodData.dropna()

        #self.crops[cropName].append(self.prodData['Tonnes/Acres'])
        x = self.prodData.drop('Tonnes/Acres', axis=1)
        #print(x)
        #self.crops[cropName].append(self.prodData['Tonnes/Acres'].values.item(0))
        y = loaded_model.predict(x)
        #As y is numpy array
        self.crops[cropName].append(y.item(0))

    def cropPrediction(self):
        cropNames = ['Rice', 'Maize', 'Jowar']
        for cropName in cropNames:
            self._dataLoading(cropName)
            self._modelLoading(cropName)


if __name__ == '__main__':
    district = sys.argv[1]
    season = sys.argv[2]
    cropYear = sys.argv[3]
    print(district, season, cropYear)
    cropPred = ProfitableCropsPrediction(district, season, int(cropYear))
    cropPred.cropPrediction()
    print(cropPred.crops)

    for crop in cropPred.crops.keys():
        if(round(cropPred.crops[crop][0], 2) == round(cropPred.crops[crop][1], 2)):
            print(crop + ' : Can continue the crop in same area\n')
        elif(round(cropPred.crops[crop][0], 2) > round(cropPred.crops[crop][1], 2)):
            print(crop + ' : Can see profit, if production area is increased\n')
        else:
            print(crop + ' : Production will be high, it will be better to cultivate other crops by reducing some cultivation area of this crop\n')