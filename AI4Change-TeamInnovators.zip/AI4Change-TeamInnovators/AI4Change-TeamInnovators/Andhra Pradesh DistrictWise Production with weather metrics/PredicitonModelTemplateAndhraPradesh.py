import keras
import sklearn
import numpy as np
import pandas as pd
from keras import optimizers
from keras.layers import Dense
from keras.models import Sequential

class PredicitonModelTemplateAndhraPradesh():
    def __init__(self, cropName):
        self.cropName = cropName
        self.prod = pd.DataFrame()
        self.reqCropProd = pd.DataFrame()
        self.model = Sequential()

    def _preparingCropData(self):
        self.prod = pd.read_csv('AndhraPradeshProduction.csv')
        self.reqCropProd = self.prod.where(self.prod['Crop'] == self.cropName)
        self.reqCropProd = self.reqCropProd.dropna()
        self.reqCropProd = self.reqCropProd.drop(columns=['State_Name', 'District_Name', 'Crop', 'Area', 'Production'])
        self.reqCropProd = pd.get_dummies(self.reqCropProd, columns=['Season'])
        self.reqCropProd['Crop_Year'] = pd.to_numeric(self.reqCropProd['Crop_Year'], downcast='integer')

    def createModel(self):
        self._preparingCropData()
        #Training Data
        X = self.reqCropProd.drop('Tonnes/Acres', axis = 1)
        Y = self.reqCropProd['Tonnes/Acres']

        #Creating Model
        self.model.add(Dense(30, input_shape=(13,), kernel_initializer='normal', activation='relu', name='InputLayer'))
        self.model.add(Dense(13, kernel_initializer='normal', activation='relu', name='HiddenLayer'))
        self.model.add(Dense(1, kernel_initializer='normal', activation='linear', name='OutputLayer'))

        #Compiling Model
        self.model.compile(loss='mse', optimizer='adam')

        #Training Model
        self.model.fit(X, Y, epochs=2500, batch_size=5, verbose=0)
        
        #Saving Model
        model_json = self.model.to_json()

        with open("Prediction_Models/AP_" + self.cropName + "_Prediction.json", "w") as json_file:
            json_file.write(model_json)

        self.model.save_weights("Prediction_Models/AP_" + self.cropName + "_Prediction_ModelWeights.h5")
        print("Saved model to disk.")
