from selenium import webdriver
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
import time
import os

path_to_chromeDriver = "D:/Users/dmunagal/Coding/BackUP Code for Hackathon/Capgemini-Hackathon/chromedriver.exe"
browser = webdriver.Chrome(executable_path = path_to_chromeDriver)
url = 'http://www.indiawaterportal.org/met_data/'
state = 'AndhraPradesh'
district = 'Krishna'

for i in range(1, 12):
    browser.get(url)

    Select(browser.find_element_by_xpath('//*[@id="stateSelect"]')).select_by_value('28')

    #delay = 5
    #districtSelect = EC.presence_of_element_located((By.XPATH, '//*[@id="districtSelect"]'))
    #WebDriverWait(browser, delay).until(districtSelect)


    time.sleep(3)
    Select(browser.find_element_by_xpath('//*[@id="districtSelect"]')).select_by_value('16')

    Select(browser.find_element_by_xpath('//*[@id="dataTypeSelect"]')).select_by_value(str(i))

    Select(browser.find_element_by_xpath('//*[@id="fromYearSelect"]')).select_by_value('1901')
    Select(browser.find_element_by_xpath('//*[@id="toYearSelect"]')).select_by_value('2002')
    browser.find_element_by_xpath('//*[@id="meanButton"]').click()

    time.sleep(3)
    browser.find_element_by_xpath('//*[@id="tableArea"]/p[2]/a[2]').click()

    colNames = ['Precipitation', 'MinTemp', 'AvgTemp', 'MaxTemp', 'CloudCover', 'VapourPressure', 'WetDayFrequency',
                    'DiurnalTemperatureRange', 'GroundFrostFrequency', 'ReferenceCropEvapotranspiration', 'PotentialEvapotranspiration']

    for file in os.listdir('.'):
        fileName, fileExtension = os.path.splitext(file)
        if fileName == 'data':
            os.rename(state + ' - ' + district + ' - ' + colNames[i] + ' 1901-2002.csv')

    time.sleep(5)
    browser.close()